import App from "@/components/app"

export default function HomePage() {
  return <App />
}
